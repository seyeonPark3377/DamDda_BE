export const SERVER_URL = "http://localhost:12002/";
