// //ui 관련 컴포턴트
// <button type="button" className="button" onClick={sample6_execDaumPostcode}>
// 우편번호 찾기
// </button>


// .button {
//     background-color: #7a82ed;
//     color: white;
//     font-weight: bold;
//     border-radius: 10px;
//     padding: 8px 16px;
//     box-shadow: none;
//     border: none;
//     transition: background-color 0.3s ease; /* Smooth transition for hover effect */
//   }
  
//   .button:hover {
//     background-color: #33C2E2;
//   }
  
  