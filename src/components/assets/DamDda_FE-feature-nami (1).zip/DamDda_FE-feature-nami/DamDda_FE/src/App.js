import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./components/pages/member/Login";
import FindID from "./components/pages/member/FindID";
import ResetPassword from "./components/pages/member/ResetPassword";
import Join from "./components/pages/member/Join";
import Detail from "./components/pages/detail/Detail";
import Register from "./components/pages/register/Register";
import ErrorPage from "./components/pages/error/ErrorPage";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/find-id" element={<FindID />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/join" element={<Join />} />

        <Route path="/detail" element={<Detail />} />
        <Route path="/register" element={<Register />} />

        <Route path="/error" element={<ErrorPage />} />
      </Routes>
    </Router>
  );
}

export default App;
