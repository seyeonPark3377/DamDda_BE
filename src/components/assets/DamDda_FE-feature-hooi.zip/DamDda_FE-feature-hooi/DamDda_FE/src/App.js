import "./App.css";
import Detail from "./components/pages/detail/Detail.jsx";

function App() {
  return (
    <>
      <Detail />
    </>
  );
}

export default App;
